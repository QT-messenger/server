#include <websocket_session.hxx>
#include <def.hxx>
#include <websocket_handlers.hxx>

namespace msserver
{
    static std::hash<std::string> hasher;
    static int64_t users_count = 0;

    static inline std::unordered_map<size_t, parsed_websocket_request_handler> get_handlers()
    {
        return {
            { hasher( "connect" ),
              handle_connect } };
    }

    json::object validate_request( const json::value &value )
    {
        if ( !value.is_object() )
        {
            throw std::exception();
        }

        json::object obj = value.as_object();

        if ( !obj.contains( "request" ) )
        {
            throw std::exception();
        }

        return obj;
    }

    websocket_handler_result handle( const std::string &str, std::string &req, std::shared_ptr<shared_state> state, std::shared_ptr<websocket_session> self )
    {
        json::object request = parse_request_string( str );

        try
        {
            return get_handlers().at( hasher( std::string( request[ "request" ].as_string() ) ) )( request, req, state, self );
        }
        catch ( std::out_of_range )
        {
            return { -1, websocket_error::wrong_request };
        }
    }

    websocket_handler_result handle_connect( const json::object &req, std::string &resp, std::shared_ptr<shared_state> state, std::shared_ptr<websocket_session> self ) noexcept
    {
        auto id = ++users_count;
        self->send( "ok" );
        return { id, msserver::websocket_error::ok };
    }

    websocket_handler_result handle_message( const json::object &req, std::string &resp, std::shared_ptr<shared_state> state, std::shared_ptr<websocket_session> self ) noexcept
    {
        req.at( "" );
    }
} // namespace msserver